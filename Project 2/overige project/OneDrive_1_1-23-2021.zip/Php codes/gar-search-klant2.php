<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>garage-search-klant2.php</title>
</head>
<body class="orbg">
     <h1>Garage Search Klant 2</h1>
     <p>
        Op klantid gegegevens zoeken uit</br>
        de tabel klant van de database garage.
     </p>
<?php

     $klantid = $_POST["klantidvak"];

     require_once "gar-connect-klant.php";
     $klanten = $conn->prepare("
      SELECT klantid, 
      klantnaam, 
      klantadres, 
      klantpostcode,
      klantplaats
      From   klant
      where  klantid = :klantid");

      $klanten->execute(["klantid" => $klantid]);
      echo "<table>";
          foreach ($klanten as $klant)
            {
              echo "<tr>";
                 echo "<td>" . $klant["klantid"] . "</td>";
                 echo "<td>" . $klant["klantnaam"] . "</td>";
                 echo "<td>" . $klant["klantadres"] . "</td>";
                 echo "<td>" . $klant["klantpostcode"] . "</td>";
                 echo "<td>" . $klant["klantplaats"] . "</td>";
              echo "</tr>";
            }
      echo "</table><br/>";
      echo "<a href='gar-menu.php'> Terug naar het Menu </a>";
?>                            
</body>
</html>