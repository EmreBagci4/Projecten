<!DOCTYPE html>
<html lang="nl">
<head>
	<meta name="author" content="Anjo Eijeriks">
  <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
	<title>auto-eigenaar3.php</title>
</head>
<body class="orbg">
    <h1>Type Auto's met Eigenaren</h1>
        <p>
            Dit document wordt gebruikt om klantgegevens
            van bepaalde autotypes te kijken/zien.
        </p>
	  <?php

            require_once "gar-connect-klant.php";
            $autotype = $_POST["autotypevak"];
 
            $klanten= $conn->prepare("SELECT     k.klantnaam, a.autokenteken,
                                                 k.klantadres, a.autotype,
                                                 k.klantid, k.klantpostcode,
                                                 k.klantplaats
                                      FROM       klant k
                                      INNER JOIN auto a on k.klantid = a.klantid
                                      Where      a.autotype = :autotype
                                    ");
            $klanten->execute(["autotype" => $autotype]);
         echo "<table>";
            foreach($klanten as $klant)
            {
            echo "<tr>";
            echo "<td>" . $klant["klantid"] ."</td>";
            echo "<td>" . $klant["klantnaam"] ."</td>";
            echo "<td>" . $klant["klantadres"] . "</td>";
            echo "<td>" . $klant["klantpostcode"] . "</td>";
            echo "<td>" . $klant["klantplaats"] . "</td>";
            echo "<td>" . $klant["autotype"] . "</td>";
            echo "<tr>";
            }
         echo "</table>";
            echo "<a href='gar-menu.php'>Terug naar het menu</a>";
    ?>
</body>
</html>