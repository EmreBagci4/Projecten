<!DOCTYPE html>
<html lang="nl">
<head>
	<meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<title>gar-create-auto1.php</title>
</head>
<body class="orbg">
	<h1>Garage Create Auto</h1>
    <p> 
    	Dit formulier wordt gebruikt om autogegevens in te voeren.
    </p>
    <form action="gar-create-auto2.php" method="post">
    	autokenteken:    <input type="text" name="autokentekenvak">    <br/>
    	automerk:        <input type="text" name="automerkvak">        <br/>
    	autotype:        <input type="text" name="autotypevak">        <br/>
    	autokmstand:     <input type="text" name="autokmstandvak">     <br/>
        klantid:         <input type="text" name="klantidvak">         <br/>
    	<input type="submit">
        <br><a href='gar-menu.php'>Terug naar het menu</a>
    </form>
</body>
</html>