<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijarika">
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>garage-update-user2.php</title>
</head>
<body>
     <h1>Garage Update User 2</h1>
     <p>
       Dit formulier wordt gebruikt om usergegevens<br>
       te wijzigen in de tabel user in de database garage.
     </p>
     <?php
         $userid = $_POST["useridvak"];
          require_once "gar-connect-user.php";
         $user = $conn->prepare('
          SELECT userid
          From   user
          where  userid = :userid');
         $user->execute(["userid" => $userid]);
         $waarde = $user-> fetch();
         if ($waarde) {
         $user = $conn->prepare(' 
          SELECT userid, 
                 usernaam, 
                 adres, 
                 postcode,
                 plaats
          From   user
          where  userid = :userid');

          $user->execute(["userid" => $userid]);
            echo "<form action='gar-update-user3.php' method='post'>";
            foreach ($user as $user);
            { 
              echo "userid:" . $user["userid"];
              echo "<input type='hidden' name='useridvak'";
              echo "value =' " . $user["userid"] . "'> <br />";

              echo "usernaam: <input type ='text'";
              echo "name = 'usernaamvak' ";
              echo "value = '".$user["usernaam"]."' ";
              echo "> <br />";

              echo "adres: <input type ='text'";
              echo "name = 'adresvak' ";
              echo "value = '".$user["adres"]."' ";
              echo "> <br />";

              echo "postcode: <input type ='text'";
              echo "name = 'postcodevak' ";
              echo "value = '".$user["postcode"]."' ";
              echo "> <br />";

              echo "plaats: <input type ='text'";
              echo "name = 'plaatsvak' ";
              echo "value = '".$user["plaats"]."' ";
              echo "> <br />";
            }

              echo "<input type='submit'>";
            echo "</form>";
         }
         else {
                  echo "<form action='gar-update-user2.php' method='post'>";
                  echo "Welk userid wilt u wijzigen?";
                  echo "<input type='text' name='useridvak'>" . "<br/>";
                  echo "<input type='submit'>";
                  echo "</form>"."<br/>";
                  echo "<script type='text/javascript'>alert('Foutmelding...');</script>";
                  echo "Het userid niet gevonden";
              }
     ?>  
</body>
</html>