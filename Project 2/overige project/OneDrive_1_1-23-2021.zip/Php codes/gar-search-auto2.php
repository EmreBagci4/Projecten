<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>gar-search-auto2.php</title>
</head>
<body class="orbg">
    <h1>Garage Search Auto</h1>
    <p>
      Op autokenteken gegegevens zoeken 
      uit de tabel klant van de database garage.
    </p>
<?php

     $autokenteken = $_POST["autokentekenvak"];

     require_once "gar-connect-auto.php";
     $autos = $conn->prepare("
                                SELECT autokenteken, 
                                       automerk, 
                                       autotype, 
                                       autokmstand,
                                       klantid
                                from   auto
                                where  autokenteken = :autokenteken
                              ");

     $autos->execute(["autokenteken" => $autokenteken]);
     echo "<table>";
         foreach ($autos as $auto)
           {
             echo "<tr>";
                echo "<td>" . $auto["autokenteken"] . "</td>";
                echo "<td>" . $auto["automerk"] . "</td>";
                echo "<td>" . $auto["autotype"] . "</td>";
                echo "<td>" . $auto["autokmstand"] . "</td>";
                echo "<td>" . $auto["klantid"] . "</td>";
             echo "</tr>";
           }
     echo "</table><br/>";
     echo "<a href='gar-menu.php'> Terug naar het Menu </a>";
?>                            
</body>
</html>