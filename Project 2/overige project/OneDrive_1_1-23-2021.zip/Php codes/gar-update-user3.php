<!DOCTYPE html>
<html lang="nl">
<head>
	<meta name="author" content="Anjo Eijeriks">
  <link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<title>garage-update-user3.php</title>
</head>
<body>
    <h1>Garage Update User 3</h1>
    <p>
    usergegevens wijzigen in de tabel<br> 
    user van de database garage.
    </p>
    <?php
$userid = $_POST["useridvak"];
$usernaam = $_POST["usernaamvak"];
$adres = $_POST["adresvak"];
$postcode = $_POST["postcodevak"];
$plaats = $_POST["plaatsvak"];

        require_once "gar-connect-user.php";
        $sql = $conn->prepare
("update user set   usernaam =:usernaam,
adres =:adres,
postcode =:postcode,
plaats =:plaats
where userid =:userid");

        $sql->execute
                     ([
"userid" => $userid,
"usernaam" => $usernaam,
"adres" => $adres,
"postcode" => $postcode,
"plaats" => $plaats,
                     ]);

      echo "De user is gewijzigd. <br />";
      echo "<a href='gar-menu.php'>Terug naar menu</a>";
    ?>
</body>
</html>