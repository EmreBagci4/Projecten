<!DOCTYPE html>
<html lang="nl">
<head>
	<meta name="author" content="Anjo Eijeriks">
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<title>gar-update-auto1.php</title>
</head>
<body class="orbg">
	<h1>Garage Update Auto</h1>
	<p>
		Dit formulier wordt gebruikt om autogegevens te wijzigen.
	</p>
	<form action="gar-update-auto2.php" method="post">
		Welk autokenteken wilt u wijzigen?
		<input type="text" name="autokentekenvak">  <br/>
		<input type="submit">
		<br>echo <a href='gar-menu.php'>Terug naar het menu</a>
	</form>
</body>
</html>