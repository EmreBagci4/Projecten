<!doctype html>
<html lang="nl">
    <head>
        <meta name="author" content="Anjo Eijeriks">
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta chatset="UTF-8">
        <title>gar-delete-klant2.php</title>  
    </head>
    <body class="orbg">
        <h1>Garage Delete Auto</h1>
        <p>
           Op autokenteken gegevens zoeken uit de
           tabel auto van de database garage
           zodat ze verwijderd kunnen worden.
        </p>
        <?php
            $autokenteken = $_POST["autokentekenvak"];
            require_once "gar-connect-auto.php";
 
             $autos = $conn->prepare("  SELECT autokenteken,
                                               automerk,
                                               autotype,
                                               autokmstand,
                                               klantid
                                        From   auto
                                        where  autokenteken = :autokenteken");
            $autos->execute(["autokenteken" => $autokenteken]);
            echo "<tabel>";
            foreach($autos as $auto)
                {
                    echo "<tr>";
                    echo "<td>" . $auto["autokenteken"] . "</td>";
                    echo "<td>" . $auto["automerk"] . "</td>";
                    echo "<td>" . $auto["autotype"] . "</td>";
                    echo "<td>" . $auto["autokmstand"] . "</td>";
                    echo "<td>" . $auto["klantid"] . "</td>";
                    echo "<tr>";
                }
            echo "</tabel><br />";
 
            echo "<form action='gar-delete-auto3.php' method='post'>";
 
                echo "<input type='hidden' name='autokentekenvak' value=$autokenteken>";
                echo "<input type='hidden'name='verwijdervak' value='0'>";
                echo "<input type='checkbox' name='verwijdervak' value='1'>";
                echo "Verwijder deze auto. <br />";
                echo "<input type='submit'>";
                echo "<a href='gar-menu.php'>Terug naar menu</a>";
            echo "</form>";
        ?>
    </body>
</html>