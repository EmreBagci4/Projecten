<!DOCTYPE html>
<html lang="nl">
<head>
	<meta name="author" content="Anjo Eijeriks">
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<title>garage-update-user1.php</title>
</head>
<body>
	<h1>Garage Update User 1</h1>
	<p>
		Dit formulier wordt gebruikt om usergegevens te wijzigen.
	</p>
	<form action="gar-update-user2.php" method="post">
		Welk userid wilt u wijzigen?
		<input type="text" name="useridvak">  <br/>
        <br>
		<input type="submit">
	</form>
</body>
</html>