<!doctype html>
<html lang="nl">
    <head>
        <meta name="author" content="Anjo Eijeriks">
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta chatset="UTF-8">
        <title>garage-delete-klant2.php</title>  
    </head>
    <body class="orbg">
        <h1>Garage Delete Klant 2</h1>
        <p>
           Op klantid gegevens zoeken uit de
           tabel klanten van de database garage
           zodat ze verwijderd kunnen worden.
        </p>
        <?php
            $klantid = $_POST["klantidvak"];
            require_once "gar-connect-klant.php";

            $klanten = $conn->prepare(' SELECT klantid
                                        From auto
                                        where klantid = :klantid
                                      ');
            $klanten->execute(["klantid" => $klantid]);
            $waarde = $klanten->fetch();
         if($waarde){
                    echo "<form action='gar-delete-klant2.php' method='post'>";
                    echo "Welk klantid wilt u verwijderen?";
                    echo "<input type='text' name='klantidvak'>"."<br/>";
                    echo "<input type='submit'>";
                    echo "</form>"."<br/>"; 
                    echo "<script type='text/javascript'>alert('Foutmelding...');</script>";
                    echo "Deze klant kan niet verwijdeerd worden want er staat nog auto's van deze klant in de tabel."."</br>";
                    echo "<a href='gar-menu.php'>Terug naar het menu</a>";
                    }
        else{
             $klanten = $conn->prepare("SELECT klantid,
                                               klantnaam,
                                               klantadres,
                                               klantpostcode,
                                               klantplaats
                                        From   klant
                                        where  klantid = :klantid");
            $klanten->execute(["klantid" => $klantid]);
            echo "<tabel>";
            foreach($klanten as $klant)
                {
                    echo "<tr>";
                    echo "<td>" . $klant["klantid"] . "</td>";
                    echo "<td>" . $klant["klantnaam"] . "</td>";
                    echo "<td>" . $klant["klantadres"] . "</td>";
                    echo "<td>" . $klant["klantpostcode"] . "</td>";
                    echo "<td>" . $klant["klantplaats"] . "</td>";
                    echo "<tr>";
                }
            echo "</tabel><br />";
 
            echo "<form action='gar-delete-klant3.php' method='post'>";
 
                echo "<input type='hidden' name='klantidvak' value=$klantid>";
                echo "<input type='hidden'name='verwijdervak' value='0'>";
                echo "<input type='checkbox' name='verwijdervak' value='1'>";
                echo "Verwijder deze klant. <br />";
                echo "<input type='submit'>";
                echo "<a href='gar-menu.php'>Terug naar het menu</a>";
            echo "</form>";
        }
        ?>
    </body>
</html>