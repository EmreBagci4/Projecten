<!DOCTYPE html>
<html lang="nl">
<head>
	<meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<title>garage-create-klant2.php</title>
</head>
<body class="orbg">
	<h1>Garage Create Klant 2</h1>
	<p>
		Een klant toevoegen aan de tabel
    klant in de database.
	</p>
    <?php
    $klantid      = NULL; 
    $klantnaam    = $_POST["klantnaamvak"];
    $klantadres   = $_POST["klantadresvak"];
    $klantpostcode= $_POST["klantpostcodevak"];
    $klantplaats  = $_POST["klantplaatsvak"];

    require_once "gar-connect-klant.php";

    $sql = $conn->prepare(
    "insert into klant values(
    :klantid, :klantnaam, :klantadres,
    :klantpostcode, :klantplaats
                              )");

    $sql->execute ([ 
"klantid"         => $klantid,
"klantnaam"       => $klantnaam,
"klantadres"      => $klantadres,
"klantpostcode"   => $klantpostcode,
"klantplaats"     => $klantplaats,
                  ]);   

    echo "De klant is toegevoegd. </br>";
    echo "<a href='gar-menu.php'> Terug naar het menu </a>";
    ?>
</body>
</html>