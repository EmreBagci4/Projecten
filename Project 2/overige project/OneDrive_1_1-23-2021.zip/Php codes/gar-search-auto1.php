<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>gar-search-auto1.php</title>
</head>
<body class="orbg">
     <h1>Garage Zoek Op Auto</h1>
     <p>
        Dit formulier een auto op 
        uit de tabal auto van de database garage.
     </p>
     <form action="gar-search-auto2.php" method="post">
       Welk autoketeken zoek u?
     <input type="text" name="autokentekenvak"> <br>
     <input type="submit">
     <br><a href='gar-menu.php'>Terug naar het menu</a>
</form>
</body>
</html>