<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijarika">
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>garage-update-klant2.php</title>
</head>
<body class="orbg">
     <h1>Garage Update Klant 2</h1>
     <p>
       Dit formulier wordt gebruikt om klantgegevens</br>
       te wijzigen in de tabel klant in de database garage.
     </p>
     <?php
         $klantid = $_POST["klantidvak"];
          require_once "gar-connect-klant.php";
         $klanten = $conn->prepare('
          SELECT klantid
          From   klant
          where  klantid = :klantid');
         $klanten->execute(["klantid" => $klantid]);
         $waarde = $klanten-> fetch();
         if ($waarde) {
         $klanten = $conn->prepare(' 
          SELECT klantid, 
                 klantnaam, 
                 klantadres, 
                 klantpostcode,
                 klantplaats
          From   klant
          where  klantid = :klantid');

          $klanten->execute(["klantid" => $klantid]);
            echo "<form action='gar-update-klant3.php' method='post'>";
            foreach ($klanten as $klant);
            { 
              echo "klantid:" . $klant["klantid"];
              echo "<input type='hidden' name='klantidvak'";
              echo "value =' " . $klant["klantid"] . "'> <br />";

              echo "klantnaam: <input type ='text'";
              echo "name = 'klantnaamvak' ";
              echo "value = '".$klant["klantnaam"]."' ";
              echo "> <br />";

              echo "klantadres: <input type ='text'";
              echo "name = 'klantadresvak' ";
              echo "value = '".$klant["klantadres"]."' ";
              echo "> <br />";

              echo "klantpostcode: <input type ='text'";
              echo "name = 'klantpostcodevak' ";
              echo "value = '".$klant["klantpostcode"]."' ";
              echo "> <br />";

              echo "klantplaats: <input type ='text'";
              echo "name = 'klantplaatsvak' ";
              echo "value = '".$klant["klantplaats"]."' ";
              echo "> <br />";
            }

              echo "<input type='submit'>";
            echo "</form>";
         }
         else {
                  echo "<form action='gar-update-klant2.php' method='post'>";
                  echo "Welk klantid wilt u wijzigen?";
                  echo "<input type='text' name='klantidvak'>" . "<br/>";
                  echo "<input type='submit'>";
                  echo "</form>"."<br/>";
                  echo "<script type='text/javascript'>alert('Foutmelding...');</script>";
                  echo "Het klantid niet gevonden";
              }
     ?>  
</body>
</html>