<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>auto-eigenaar2.php</title>
</head>
<body class="orbg">
     <h1>Type Auto's met Klantgegevens</h1>
     <p>
        Dit document wordt gebruikt om klantgegevens te zoeken
        van bepaalde type auto's.
     </p>
     <form action="auto-eigenaar3.php" method="post">
       Welke autotype zoekt u?
     <input type="text" name="autotypevak"> <br>
     <input type="submit">
     <br><a href='gar-menu.php'>Terug naar het menu</a>
</form>
</body>
</html>