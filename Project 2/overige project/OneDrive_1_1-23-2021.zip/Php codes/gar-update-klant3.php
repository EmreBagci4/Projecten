<!DOCTYPE html>
<html lang="nl">
<head>
	<meta name="author" content="Anjo Eijeriks">
  <link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<title>garage-update-klant3.php</title>
</head>
<body class="orbg">
    <h1>Garage Update Klant 3</h1>
    <p>
    klantgegevens wijzigen in de tabel</br> 
    klant van de database garage.
    </p>
    <?php
$klantid = $_POST["klantidvak"];
$klantnaam = $_POST["klantnaamvak"];
$klantadres = $_POST["klantadresvak"];
$klantpostcode = $_POST["klantpostcodevak"];
 $klantplaats = $_POST["klantplaatsvak"];

        require_once "gar-connect-klant.php";
        $sql = $conn->prepare
("update klant set   klantnaam =:klantnaam,
klantadres =:klantadres,
klantpostcode =:klantpostcode,
klantplaats =:klantplaats
where klantid =:klantid");

        $sql->execute
                     ([
"klantid" => $klantid,
"klantnaam" => $klantnaam,
"klantadres" => $klantadres,
"klantpostcode" => $klantpostcode,
"klantplaats" => $klantplaats,
                     ]);

      echo "De klant is gewijzigd. <br />";
      echo "<a href='gar-menu.php'>Terug naar het menu</a>";
    ?>
</body>
</html>