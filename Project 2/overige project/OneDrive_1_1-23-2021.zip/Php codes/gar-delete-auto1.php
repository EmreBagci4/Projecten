<!doctype html>
<html lang="nl">
    <head>
        <meta name="author" content="Anjo Eijeriks">
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta charset="utf-8">
        <title>gar-delete-klant1.php</title>   
    </head>
<body class="orbg">
      <h1>Garage Delete Auto</h1>
      <p>
        Dit formulier zoekt een auto op uit 
        de tabel auto van database garage 
        om hem te kunnen verwijderen.
      </p>
      <form action="gar-delete-auto2.php" method="post">
         Welk autokenteken wilt u verwijderen?
         <input type="text" name="autokentekenvak"> <br />
         <input type="Submit">
         <br><a href='gar-menu.php'>Terug naar het menu</a>
      </form>
</body>
</html>