<!DOCTYPE html>
<html lang="nl">
<head>
	<meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<title>garage-create-klant1.php</title>
</head>
<body class="orbg">
	<h1>Garage Create Klant 1</h1>
    <p> 
    	Dit formulier wordt gebruikt om klantgegevens in te voeren.
    </p>
    <form action="gar-create-klant2.php" method="post">
    	klantnaam:      <input type="text" name="klantnaamvak">      <br/>
    	klantadres:     <input type="text" name="klantadresvak">     <br/>
    	klantpostcode:  <input type="text" name="klantpostcodevak">  <br/>
    	klantplaats:    <input type="text" name="klantplaatsvak">    <br/>
    	<input type="submit">
        <br><a href='gar-menu.php'>Terug naar het menu</a>
    </form>
</body>
</html>