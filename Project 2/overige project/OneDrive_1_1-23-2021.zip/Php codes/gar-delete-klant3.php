<!doctype html>
<html lang="nl">
    <head>
        <meta name="author" content="Anjo Eijeriks">
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta charset="utf-8">
        <title>garage-delete-klant3.php</title>   
    </head>
<body class="orbg">
      <h1>Garage Delete Klant 3</h1>
      <p>
        Op klantid gegevens zoeken uit de </br>
        tabel klanten van de database garage</br> 
        zodat ze verwijderd kunnen worden.
      </p>
    <?php
        $klantid = $_POST["klantidvak"];
        $verwijderen = $_POST["verwijdervak"];
    
        if($verwijderen)
        {
           require_once "gar-connect-klant.php";
           $sql = $conn->prepare("
            delete from klant
            where klantid = :klantid");
           
           $sql->execute(["klantid" => $klantid]);
           echo "De gegevens zijn verwijderd. <br />";
    
        }
       else
        {
           echo "De gegevens zijn niet verwijderd. <br />";
        }
           echo "<a href='gar-menu.php'>Terug naar het menu</a>";
    ?>
</body>
</html>