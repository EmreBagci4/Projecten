<!DOCTYPE html>
<html lang="nl">
<head>
	<meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<title>garage-create-user1.php</title>
</head>
<body>
	<h1>Garage Create User 1</h1>
    <p> 
    	Dit formulier wordt gebruikt om gebruikergegevens in te voeren.
    </p>
    <form action="gar-create-user2.php" method="post">
    	usernaam:      <input type="text" name="usernaamvak">      <br/>
    	adres:     <input type="text" name="adresvak">     <br/>
    	postcode:  <input type="text" name="postcodevak">  <br/>
    	plaats:    <input type="text" name="plaatsvak">    <br/>
        <br>
    	<input type="submit">
    </form>
</body>
</html>