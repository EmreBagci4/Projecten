<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "garage";

try
{
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    //echo "Connectie gelukt <br />";
}
catch(PDOExeption $e)
{
    echo "Connectie mislukt" . $e->getMessage();
}
?>