<!DOCTYPE html>
<html lang="nl">
    <head>
        <meta name="author" content="Anjo Eijeriks">
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta charset="UTF-8">
        <title>gar-update-auto2.php </title>
    </head>
    <body class="orbg">
        <h1>Garage Update Auto</h1>
        <p>
            Dit formulier wordt gebruikt om autogegevens 
            te wijzigen in de tabel auto in de database garage.
        </p>
        <?php 
 
            $autokenteken= $_POST["autokentekenvak"];
            require_once "gar-connect-auto.php";
            $autos = $conn->prepare('
                                       SELECT autokenteken
                                       From   auto
                                       where  autokenteken = :autokenteken');
            $autos->execute(["autokenteken" => $autokenteken]);
            $waarde = $autos-> fetch();
               if ($waarde) {
                              $autos = $conn->prepare(" 
                                                       SELECT autokenteken,
                                                              automerk,
                                                              autotype,
                                                              autokmstand,
                                                              klantid
                                                       from   auto
                                                       where  autokenteken = :autokenteken");
            $autos->execute(["autokenteken" => $autokenteken]);
            echo "<form action ='gar-update-auto3.php' method='post'>";
               foreach ($autos as $auto )
                 {
 
                   echo "autokenteken: <input type='text'";
                   echo "name = 'autokentekenvak'";
                   echo "value = '" .$auto["autokenteken"]. "' " ;
                   echo "> </br>" ;
 
                   echo " autotype : <input type='text' " ;
                   echo "name = 'autotypevak'" ;
                   echo "value = '" . $auto["autotype"]. "'" ;
                   echo "> </br>" ;
 
                  echo " automerk: <input type='text' " ;
                  echo "name = 'automerkvak'" ;
                  echo "value = '" . $auto["automerk"]. "'" ;
                  echo "> </br>" ;
 
                  echo " autokmstand : <input type='text' " ;
                  echo "name = 'autokmstandvak'" ;
                  echo "value = '" . $auto["autokmstand"]. "'" ;
                  echo "> </br>" ;
     
                  echo " klantid :". $auto["klantid"];
                  echo "<input type='hidden' name='klantidvak'";
                  echo "value = ' " . $auto["klantid"]."'> <br/> " ;
                 }
                  echo "<input type='submit'>";
            echo "</form>";
             }
               else {
                  echo "<form action='gar-update-auto2.php' method='post'>";
                  echo "Welk autokenteken wilt u wijzigen?";
                  echo "<input type='text' name='autokentekenvak'>" . "<br/>";
                  echo "<input type='submit'>";
                  echo "</form>"."<br/>";
                  echo "<script type='text/javascript'>alert('Foutmelding...');</script>";
                  echo "Het autokenteken niet gevonden!";
              }
        ?>
    </body>
    </html>