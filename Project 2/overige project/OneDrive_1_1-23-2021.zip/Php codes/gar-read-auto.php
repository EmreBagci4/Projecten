<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijarika">
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>gar-read-auto.php</title>
</head>
<body class="orbg">
    <h1>Garage Read Auto</h1>
    <p>
       Dit zijn alle gegevens uit de 
       tabel auto van de database garage
    </p>
<?php

    require_once "gar-connect-auto.php";

    $autos = $conn->prepare('   SELECT  autokenteken, 
                                        automerk, 
                                        autotype, 
                                        autokmstand,
                                        klantid
                                From    auto
                            ');
                            
    $autos->execute();
    echo "<table>";
     foreach ($autos as $auto)
      {
        echo "<tr>";
           echo "<td>" . $auto["autokenteken"] . "</td>";
           echo "<td>" . $auto["automerk"] . "</td>";
           echo "<td>" . $auto["autotype"] . "</td>";
           echo "<td>" . $auto["autokmstand"] . "</td>";
           echo "<td>" . $auto["klantid"] . "</td>";
        echo "</tr>";
      }
    echo "</table>";
    echo "<a href='gar-menu.php'> Terug naar het Menu </a>";
?>                            
</body>
</html>