<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>garage-search-klant1.php</title>
</head>
<body class="orbg">
     <h1>Garage Zoek Op Klant 1</h1>
     <p>
       Dit formulier een klant op uit 
       de tabal klant van de database garage.
     </p>
     <form action="gar-search-klant2.php" method="post">
       Welk klantid zoek u?
     <input type="text" name="klantidvak"> <br>
     <input type="submit">
     <br><a href='gar-menu.php'>Terug naar het menu</a>
</form>
</body>
</html>