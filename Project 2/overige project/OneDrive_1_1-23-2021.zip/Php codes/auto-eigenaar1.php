<!DOCTYPE html>
<html lang="nl">
<head>

	<meta name="author" content="Anjo Eijeriks">
  <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
	<title>auto-eigenaar1.php</title>

</head>
<body class="orbg">

	<?php
        require_once "gar-connect-klant.php";
 
        $klanten= $conn->prepare("SELECT k.klantid, 
                                         k.klantnaam, 
                                         a.autokenteken,
                                         a.automerk , 
                                         a.autotype
                                  FROM   klant k
                                  INNER JOIN auto a on k.klantid = a.klantid
                                ");

            $klanten->execute();
    echo "<table>";
            foreach($klanten as $klant)
        {
        echo "<tr>";
        echo "<td>" . $klant["klantid"] ."</td>";
        echo "<td>" . $klant["klantnaam"] ."</td>";
        echo "<td>" . $klant["autokenteken"] ."</td>";
        echo "<td>" . $klant["automerk"] . "</td>";
        echo "<td>" . $klant["autotype"] ."</td>";
        echo "<tr>";
        }

    echo "</table>";
        echo "<a href='gar-menu.php'> terug naar het menu </a>";
    ?>
</body>
</html>