<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>garage-search-user1.php</title>
</head>
<body>
     <h1>Garage Zoek Op User 1</h1>
     <p>
       Dit formulier een user op uit 
       de tabal user van de database garage.
     </p>
     <form action="gar-search-user2.php" method="post">
       Welk userid zoek u?
     <input type="text" name="useridvak"> 
         <br> <br>
     <input type="submit">
</form>
</body>
</html>