<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>garage-search-user2.php</title>
</head>
<body>
     <h1>Garage Search User 2</h1>
     <p>
        Op userid gegegevens zoeken uit<br>
        de tabel user van de database garage.
     </p>
<?php

     $userid = $_POST["useridvak"];

     require_once "gar-connect-klant.php";
     $user = $conn->prepare("
      SELECT klantid, 
      usernaam, 
      adres, 
      postcode,
      plaats
      From   user
      where  userid = :userid");

      $user->execute(["userid" => $userid]);
      echo "<table>";
          foreach ($user as $user)
            {
              echo "<tr>";
                 echo "<td>" . $user["userid"] . "</td>";
                 echo "<td>" . $user["usernaam"] . "</td>";
                 echo "<td>" . $user["adres"] . "</td>";
                 echo "<td>" . $user["postcode"] . "</td>";
                 echo "<td>" . $user["plaats"] . "</td>";
              echo "</tr>";
            }
      echo "</table><br/>";
      echo "<a href='gar-menu.php'> Terug naar Menu </a>";
?>                            
</body>
</html>