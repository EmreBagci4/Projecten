<!doctype html>
<html lang="nl">
    <head>
        <meta name="author" content="Anjo Eijeriks">
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta charset="utf-8">
        <title>garage-delete-user1.php</title>   
    </head>
<body>
      <h1>Garage Delete User 1</h1>
      <p>
        Dit formulier zoekt een gebruiker op uit<br> 
        de tabel user van database garage<br>
        om hem te kunnen verwijderen.
      </p>
<form action="gar-delete-user2.php" method="post">
Welk klantid wilt u verwijderen?
<input type="text" name="useridvak"> <br>
<input type="submit">
      </form>
</body>
</html>