<!DOCTYPE html>
<html lang="nl">
<head>
	<meta name="author" content="Anjo Eijeriks">
  <link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<title>gar-update-auto3.php</title>
</head>
<body class="orbg">
    <h1>Garage Update Auto</h1>
    <p>
     Autogegevens wijzigen in de tabel klant van de database garage.
    </p>
    <?php
       $autokenteken = $_POST["autokentekenvak"];
       $automerk = $_POST["automerkvak"];
       $autotype = $_POST["autotypevak"];
       $autokmstand = $_POST["autokmstandvak"];
       $klantid = $_POST["klantidvak"];

       require_once "gar-connect-auto.php";
       $sql = $conn->prepare(" update auto set  automerk = :automerk,
                                                autotype = :autotype,
                                                autokmstand = :autokmstand,
                                                klantid = :klantid
                                                where autokenteken = :autokenteken
                            ");

       $sql->execute
                     ([
                       "autokenteken" => $autokenteken,
                       "automerk"     => $automerk,
                       "autotype"     => $autotype,
                       "autokmstand"  => $autokmstand,
                       "klantid"      => $klantid
                     ]);

       echo "De auto is gewijzigd. <br />";
       echo "<a href='gar-menu.php'>Terug naar het menu</a>";
    ?>
</body>
</html>