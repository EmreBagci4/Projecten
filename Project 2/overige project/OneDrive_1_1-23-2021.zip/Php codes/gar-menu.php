<!doctype html>
<html lang="nl">
    <head>
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta charset="utf-8">
        <title> Garage Ertan</title>   
    </head>
    <body>
            <nav>
        <p class="logo">Ertan</p>
    <ul>
        <li><a href="">Klant</a>
            <ul>
            <li><a href="gar-create-klant1.php">Create</a></li>
            <li><a href="gar-read-klant.php">Read</a></li>
            <li><a href="gar-search-klant1.php">Search</a></li>
            <li><a href="gar-update-klant1.php">Update</a></li>
            <li><a href="gar-delete-klant1.php">Delete</a></li>
        </ul>
    </ul>

    <ul>
        <li><a href="">Auto</a>
        <ul>
        <li><a href="gar-create-auto1.php">Create</a></li>
        <li><a href="gar-read-auto.php">Read</a></li>
        <li><a href="gar-search-auto1.php">Search</a></li>
        <li><a href="gar-update-auto1.php">Update</a></li>
        <li><a href="gar-delete-auto1.php">Delete</a></li>
        </ul>
    </ul>

    <ul>
        <li><a href="">Auto en eigenaar</a>
    <ul>
        <li><a href="auto-eigenaar1.php">Auto en eigenaar</a></li>
        <li><a href="auto-eigenaar2.php">Auto type met eigenaar</a></li>
    </ul>

    </ul>
    </nav>
</body>
</html>