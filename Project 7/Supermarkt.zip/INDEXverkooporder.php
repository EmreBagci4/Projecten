<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verkooporder</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
 <div class="topnav">
			<a href="index.php">Home</a>
			<a href="ADDklant.php">voeg klant toe</a>
            <a href="INDEXklant.php">zie klant</a>
    
			<a href="ADDverkooporder.php">voeg verkooporder toe</a>
			<a href="INDEXverkooporder.php">zie verkooporders</a>
			<a href="ADDinkooporder.php">voeg inkooporder</a>
			<a href="INDEXinkooporder.php">zie inkooporder</a>
			<a href="INDEXleveranciers.php">zie leverancier</a>
            <a href="INDEXArtikelen.php">zie artikelen</a>

		</div>
<?php
include "connect.php";
include "Verkooporder.php";

$Verkooporder = new Verkooporder;
//Toon Verkooporders
$toonOrders = $Verkooporder->haalVerkooporder();

$Verkooporder->toonVerkooporder($toonOrders);

?>
</body>
</html>

